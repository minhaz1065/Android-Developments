package com.miskd.cameraapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void mymethod(View view){
        boolean checked = ((RadioButton) view).isChecked();
        if(checked){
            if(view.getId()==R.id.fruit_apple)
            {
                Toast.makeText(MainActivity.this,"You have clicked apple!",Toast.LENGTH_LONG).show();
            }
            else if(view.getId()==R.id.fruit_orange)
            {
                Toast.makeText(MainActivity.this,"You have clicked orange!",Toast.LENGTH_LONG).show();
            }
            else if(view.getId()==R.id.fruit_banana)
            {
                Toast.makeText(MainActivity.this,"You have clicked banana!",Toast.LENGTH_LONG).show();
            }
            else if(view.getId()==R.id.fruit_pineapple)
            {
                Toast.makeText(MainActivity.this,"You have clicked pineapple!",Toast.LENGTH_LONG).show();
            }

        }
        else
        {
            Toast.makeText(MainActivity.this,"Wrong click!", Toast.LENGTH_SHORT).show();
        }
    }

}
